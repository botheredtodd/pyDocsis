from setuptools import setup

setup(
    name='pyDocsis',
    version='0.0',
    packages=['pydocsis'],
    url='https://github.com/botheredtodd/pyDocsis',
    license='LGPL-3.0 license',
    author='Todd Balsley',
    author_email='',
    description=''
)
